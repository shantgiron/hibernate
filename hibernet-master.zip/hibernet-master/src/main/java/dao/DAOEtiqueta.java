package dao;

import entidades.Etiqueta;
import java.util.List;

public interface DAOEtiqueta extends DAO <Etiqueta, Long> {
    @Override

    void insertar(Etiqueta etiqueta);

    @Override

    void actualizar(Etiqueta etiqueta);

    @Override

    void borrar(Etiqueta etiqueta);

    @Override

    Etiqueta encontrarPorId(Long aLong);

    @Override

    List<Etiqueta> encontrarTodos();

    Etiqueta encontrarPorEtiqueta(String etiqueta);
}
