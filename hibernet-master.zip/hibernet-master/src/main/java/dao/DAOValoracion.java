package dao;

import entidades.Usuario;
import entidades.Valoracion;
import java.util.List;

public interface DAOValoracion extends DAO <Valoracion, Long> {
    @Override

    void insertar(Valoracion valoracion);

    @Override

    void actualizar(Valoracion valoracion);

    @Override

    void borrar(Valoracion valoracion);

    @Override

    Valoracion encontrarPorId(Long aLong);

    @Override

    List<Valoracion> encontrarTodos();

    Usuario encontrarUsuarioValoracion(Usuario usuario);

    Valoracion encontrarValoracion(Usuario usuario, Long id);
}
