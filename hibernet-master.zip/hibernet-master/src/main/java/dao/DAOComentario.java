package dao;

import entidades.Comentario;
import java.util.List;

public interface DAOComentario extends DAO<Comentario, Long> {
    @Override

    void insertar(Comentario comentario);

    @Override

    void actualizar(Comentario comentario);

    @Override

    void borrar(Comentario comentario);

    @Override

    Comentario encontrarPorId(Long aLong);

    @Override
    List<Comentario> encontrarTodos();

}
